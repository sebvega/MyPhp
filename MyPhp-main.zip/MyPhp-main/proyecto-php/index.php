<?php //include 'includes/header.php' 
	require_once 'includes/header.php';?>
<?php require_once 'includes/barraLateral.php'; ?>

<!-- contenido principal -->
<div id="principal">
	<h1>ultimas entradas</h1>
	<article class="entrada">
		<a href="">
			<h2>Titulo de mi entrada</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque dapibus ante ac felis tristique, non malesuada libero mattis. Cras lectus justo, aliquam vel facilisis vel, euismod id orci. Nunc sed mi pellentesque, mattis tortor sed, lobortis tortor. Duis vitae elit vitae ante pellentesque feugiat. Cras at cursus est. Proin maximus fringilla facilisis. Pellentesque mi elit, pellentesque in vestibulum id, euismod non odio. Pellentesque vel fermentum massa. Aenean eget tortor euismod nulla dignissim commodo sed sed ipsum
			</p>
		</a>
	</article>
	<article class="entrada">
		<a href="">
			<h2>Titulo de mi entrada</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque dapibus ante ac felis tristique, non malesuada libero mattis. Cras lectus justo, aliquam vel facilisis vel, euismod id orci. Nunc sed mi pellentesque, mattis tortor sed, lobortis tortor. Duis vitae elit vitae ante pellentesque feugiat. Cras at cursus est. Proin maximus fringilla facilisis. Pellentesque mi elit, pellentesque in vestibulum id, euismod non odio. Pellentesque vel fermentum massa. Aenean eget tortor euismod nulla dignissim commodo sed sed ipsum
			</p>
		</a>
	</article>
	<article class="entrada">
		<a href="">
			<h2>Titulo de mi entrada</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque dapibus ante ac felis tristique, non malesuada libero mattis. Cras lectus justo, aliquam vel facilisis vel, euismod id orci. Nunc sed mi pellentesque, mattis tortor sed, lobortis tortor. Duis vitae elit vitae ante pellentesque feugiat. Cras at cursus est. Proin maximus fringilla facilisis. Pellentesque mi elit, pellentesque in vestibulum id, euismod non odio. Pellentesque vel fermentum massa. Aenean eget tortor euismod nulla dignissim commodo sed sed ipsum
			</p>
		</a>
	</article>
	<article class="entrada">
		<a href="">
			<h2>Titulo de mi entrada</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque dapibus ante ac felis tristique, non malesuada libero mattis. Cras lectus justo, aliquam vel facilisis vel, euismod id orci. Nunc sed mi pellentesque, mattis tortor sed, lobortis tortor. Duis vitae elit vitae ante pellentesque feugiat. Cras at cursus est. Proin maximus fringilla facilisis. Pellentesque mi elit, pellentesque in vestibulum id, euismod non odio. Pellentesque vel fermentum massa. Aenean eget tortor euismod nulla dignissim commodo sed sed ipsum
			</p>
		</a>
	</article>
	<div id="ver-todas">
		<a href="">ver todas las entradas</a>
	</div>
</div><!-- fin principal -->

<?php require_once 'includes/foot.php'; ?>