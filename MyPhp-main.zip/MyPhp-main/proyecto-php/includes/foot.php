<div class="clearfix">
	
</div>
</div><!-- fin contenedor -->
<!-- pie de pagina -->
<footer id="foot">
	<p>
		Desarrollado por sebastian sanchez &copy; 2021
	</p>
</footer>
</body>
</html>
