<?php 

// constantes
// es un contenedor de informacion que no puede variar

define('nombre', 'sebastian');
define('nombre2', 'laura');
echo nombre;
 echo PHP_OS;
echo ;
 ?>