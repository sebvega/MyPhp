<?php 


echo $_POST['nombre'];
echo $_POST['apellido'];
echo $_POST['edad'];

 ?>