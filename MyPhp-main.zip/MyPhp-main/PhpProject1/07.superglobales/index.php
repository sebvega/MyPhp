<?php 
//variables super globales

//variables de servidor
echo '<br>'.$_SERVER['SERVER_ADDR'];
echo '<br>'.$_SERVER['SERVER_NAME'];
echo '<br>'.$_SERVER['SERVER_SOFTWARE'];
echo '<br>'.$_SERVER['HTTP_USER_AGENT'];
echo '<br>'.$_SERVER['REMOTE_ADDR'];


 ?>