<?php 

$mi_variable= "hola mundo desde una variable";
$numero=44;
$verdadero= true;


print($mi_variable);

print_r($mi_variable);
echo "<br>".$mi_variable;

 ?>