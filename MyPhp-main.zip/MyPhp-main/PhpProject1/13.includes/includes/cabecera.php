<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>includes</title>
</head>
<body>
	<!-- cabecera -->
	<div class="cabecera">
		<h1>Includes en Php</h1>
		<ul>
			<li><a href="index.php">inicio</a></li>
			<li><a href="sobremi.php">sobre nosotros</a></li>
			<li><a href="contactenos.php">contactennos</a></li>
		</ul>
	</div>
