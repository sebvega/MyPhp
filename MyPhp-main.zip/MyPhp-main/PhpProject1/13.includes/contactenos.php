<?php 
include 'includes/cabecera.php';
 ?>
	<hr>
	<div>
		<h2>esta es la paguina de contactenos</h2>
		<p>texto de prueba de la pagina de contactenos</p>
	</div>
<hr>
	<!-- pie de paguina -->
<?php include 'includes/piedepag.php'; ?>