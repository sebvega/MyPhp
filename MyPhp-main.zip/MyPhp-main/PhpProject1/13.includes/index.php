<?php include 'includes/cabecera.php'; ?>

	<hr>
	<!-- contenido -->
	<div>
		<h2>esta es la paguina de inicio</h2>
		<p>texto de prueba de la pagina de inicio</p>
	</div>
<hr>
	<!-- pie de paguina -->


<?php include 'includes/piedepag.php'; 

// es mucho mejor usar el require_once ya que es estricto al no encontrar el archivo se detiene todo
?>