<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>imprimir en pantalla</title>
</head>
<body>
	<h1>todo de php</h1>
	<?php /*      */  //titular
		echo '<h3>lista de video juegos</h3>';
		echo "<ul>"
			."<li>GTA</li>"
			."<li>PES</li>"
			."<li>AOE</li>"
			."</ul>";
			echo '<p>esta es toda'.' - '.'lista de juegos</p>';

	 ?>
	 <?="holamundo"?>
</body>
</html>