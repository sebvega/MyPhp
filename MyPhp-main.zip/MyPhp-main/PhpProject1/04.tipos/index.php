<?php 

/*  
tipos de datos

*numero entero (int/ ingteger) =99
*numero flotante/ con decimales  (float/double) =3,1415
*cadenas de datos (string)="hola soy un string"
*boleanos (bool)= true/false
*dato nulo (null)= absolutamente nada adentro
*array (coleccion de datos)
objetos

*/

$numero[]= "hola mundo";
$numero[]= "hola mundo";
$decimal= 27.9;



var_dump($numero);
 ?>