<?php 
//operadores aritmeticos
$numero1=55;
$numero2=33;


echo 'Suma:'.($numero1+$numero2);

 ?>