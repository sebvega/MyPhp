<?php 


$resultado=0;

for ($i=0; $i <= 100; $i++) { 
	$resultado+=$i;
}
echo "$resultado";
 ?>