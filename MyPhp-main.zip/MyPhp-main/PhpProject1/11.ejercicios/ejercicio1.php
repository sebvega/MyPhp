<?php 
$pais="colombia";
$continente="america";	


echo $pais .' es un pais de '. $continente.'<br>';
var_dump($pais);echo "<br>";
var_dump($continente);

 ?>