<?php 

for ($i=1; $i <=40 ; $i++) { 
	//echo ($i*$i).'<br>';
}
$j=1;
while ( $j<= 40) {
	echo ($j*$j).'<br>';
	$j++;
}
 ?>