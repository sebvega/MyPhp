<?php 

$cadena=array();
$cantidad=120;

for ($i=0; $i <120 ; $i++) { 
	array_push($cadena, rand(0,9));

}
var_dump($cadena);

 ?>