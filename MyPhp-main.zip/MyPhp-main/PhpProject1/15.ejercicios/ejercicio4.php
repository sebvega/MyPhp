<?php 

$cadena=$array('holamundo',88 );
$string="hola mundo";
$numero=33;
$desicion=true;

if (is_array($string)) {
	# code...
}elseif (is_string($$string)) {
	# code...
}elseif (is_numeric($numero)) {
	# code...

}elseif (is_bool($desicion)) {
	# code...
}

 ?>