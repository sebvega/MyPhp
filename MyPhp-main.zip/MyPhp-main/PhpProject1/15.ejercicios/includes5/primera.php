<tr>
		<td><?= $cadena['accion'][0] ?></td>
		<td><?= $cadena['aventura'][0] ?></td>
		<td><?= $cadena['deportes'][0] ?></td>
	</tr>