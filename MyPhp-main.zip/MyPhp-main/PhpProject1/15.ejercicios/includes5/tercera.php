<tr>
		<td><?= $cadena['accion'][2] ?></td>
		<td><?= $cadena['aventura'][2] ?></td>
		<td><?= $cadena['deportes'][2] ?></td>
	</tr>