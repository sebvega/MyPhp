<tr>
		<td><?= $cadena['accion'][1] ?></td>
		<td><?= $cadena['aventura'][1] ?></td>
		<td><?= $cadena['deportes'][1] ?></td>
	</tr>