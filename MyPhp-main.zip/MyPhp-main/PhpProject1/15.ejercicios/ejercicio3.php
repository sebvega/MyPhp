<?php 

$cadena='';


if (empty($cadena)) {
	$cadena="soy minuscula";
}
echo "<strong>".strtoupper($cadena)."</strong>";

 ?>