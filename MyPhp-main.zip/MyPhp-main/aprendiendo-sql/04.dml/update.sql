#modificar filas   actualizar datos

UPDATE usuarios SET fechaRegistro =CURDATE() WHERE id= 3;