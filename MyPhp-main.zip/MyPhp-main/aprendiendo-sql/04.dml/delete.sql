#eliminar informacion y tablas


#registros

DELETE FROM usuarios WHERE email ='sanchez@gmail.com';