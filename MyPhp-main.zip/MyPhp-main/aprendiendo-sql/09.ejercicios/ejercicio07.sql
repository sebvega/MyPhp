/*
mostrar el nombre y el salario de los vendedores con cargo de ayudante de tienda

*/

SELECT nombre, sueldo FROM vendedores WHERE cargo ='Ayudante de tienda';