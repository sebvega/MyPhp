/*
sacar a todos los vendedores cuya fecha de inicio sea posterior al 1 de julio del 2018


*/

SELECT * FROM vendedores WHERE fecha_inicio >='2020-07-01';