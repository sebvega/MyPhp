/*
inclementar el precio de los coches en un 5%

*/

UPDATE coches SET precio =(precio*1.05);