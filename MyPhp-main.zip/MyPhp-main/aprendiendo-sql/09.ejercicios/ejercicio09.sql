/*
mostrar todos los vendedores del grupo 2 ordenados por salario

*/

select * from vendedores WHERE grupos_id =2 ORDER BY sueldo DESC;