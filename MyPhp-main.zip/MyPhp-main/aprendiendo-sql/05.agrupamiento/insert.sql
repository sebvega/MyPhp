#inserts para categorias

INSERT INTO categorias VALUES (null,'Accion');
INSERT INTO categorias VALUES (null,'Rol');
INSERT INTO categorias VALUES (null,'Deportes');



#inserts para entradas

INSERT INTO entradas VALUES (null,1,1,'Primeras impresiones, GTAV','Review del GTA 5', CURDATE()); 
INSERT INTO entradas VALUES (null,1,2,'de manco a pro LOL','todo sobre LOL', CURDATE()); 
INSERT INTO entradas VALUES (null,1,3,'nuevos personajes de fifa','Review de fifa 20', CURDATE()); 

INSERT INTO entradas VALUES (null,2,1,'Primeras impresiones, assassins','Review del assassins', CURDATE()); 
INSERT INTO entradas VALUES (null,2,2,'de manco a pro WOW online','todo sobre WOW online', CURDATE()); 
INSERT INTO entradas VALUES (null,2,3,'nuevos personajes de pes20','Review de pes20', CURDATE()); 

INSERT INTO entradas VALUES (null,3,1,'novedades de carlos duty','day zero', CURDATE()); 
INSERT INTO entradas VALUES (null,3,2,'mundo de terraria','todo sobre terraria', CURDATE()); 
INSERT INTO entradas VALUES (null,3,3,'nuevos personajes de formula 1 2021','Review de formula 1 2021', CURDATE()); 