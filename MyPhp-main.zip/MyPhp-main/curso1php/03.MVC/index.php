<?php 

#ssalidas DE LAS VISTAS AL USUARIO

require_once "controladores/plantilla.controlador.php";
require_once "controladores/formularios.controlador.php";


$plantilla = new ControladorPlantilla();
$plantilla -> ctrTraerPlantilla();



