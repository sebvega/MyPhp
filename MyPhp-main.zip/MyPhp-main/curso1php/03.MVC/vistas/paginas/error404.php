<div class ="text-center">

<h1>404</h1>
<p>pagina no encotrada</p>
<a href="index.php?pagina=registro"class="btn btn-primary">volver</a>
</div>