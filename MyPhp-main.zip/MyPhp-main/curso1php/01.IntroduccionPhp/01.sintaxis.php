<?php
print "<h1>mi primer codigo!!!";
echo "<p>mi primer echo en php", "<h3>01.sintaxis.php";






?>